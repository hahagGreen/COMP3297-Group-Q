from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(User)
admin.site.register(Accommodation)
admin.site.register(Reservation)
admin.site.register(Rating)
admin.site.register(Campus)
