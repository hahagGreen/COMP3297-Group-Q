# reservations/urls.py
from django.urls import path
from .views import ReservationListView, AddReservationView, CancelReservationView

urlpatterns = [
    path('list/<int:user_id>/', ReservationListView.as_view(), name='reservation_list'),
    path('add/<int:user_id>/<int:accommodation_id>/', AddReservationView.as_view(), name='add_reservation'),
    path('cancel/<int:user_id>/<int:reservation_id>/', CancelReservationView.as_view(), name='cancel_reservation'),
]