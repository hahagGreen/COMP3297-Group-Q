# reservations/serializers.py
from rest_framework import serializers
from .models import Reservation


class ReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reservation
        fields = '__all__'
        read_only_fields = ('user', 'accommodation', 'status')


class CreateReservationSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()
    accommodation_id = serializers.IntegerField()