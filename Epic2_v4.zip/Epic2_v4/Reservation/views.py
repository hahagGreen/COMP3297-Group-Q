from datetime import datetime
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Reservation, Accommodation, User
from .serializers import ReservationSerializer, CreateReservationSerializer


class ReservationListView(APIView):
    def get(self, request, user_id):
        user = get_object_or_404(User, pk=user_id)
        reservations = Reservation.objects.filter(user=user)
        serializer = ReservationSerializer(reservations, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class AddReservationView(APIView):

    def post(self, request, user_id, accommodation_id):
        user = get_object_or_404(User, pk=user_id)
        accommodation = get_object_or_404(Accommodation, pk=accommodation_id)

        if accommodation.is_reserved:
            return Response({"error": "The selected accommodation is already reserved."}, status=status.HTTP_400_BAD_REQUEST)

        if Reservation.objects.filter(user=user, status=Reservation.PENDING).exists():
            return Response({"error": "You already have a pending reservation."}, status=status.HTTP_400_BAD_REQUEST)

        user_reservations = Reservation.objects.filter(user=user)
        for res in user_reservations:
            if not (accommodation.availability_end < res.accommodation.availability_start or
                    accommodation.availability_start > res.accommodation.availability_end):
                return Response({"error": "Reservation time overlaps with an existing reservation."}, status=status.HTTP_400_BAD_REQUEST)

        reservation = Reservation.objects.create(
            user=user,
            accommodation=accommodation,
            status=Reservation.PENDING
        )

        accommodation.is_reserved = True
        accommodation.save()

        serializer = ReservationSerializer(reservation)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class CancelReservationView(APIView):

    def post(self, request, user_id, reservation_id):
        reservation = get_object_or_404(Reservation, pk=reservation_id, user__user_id=user_id)

        accommodation = reservation.accommodation
        accommodation.is_reserved = False
        accommodation.save()

        reservation.delete()

        return Response({"message": "Reservation canceled successfully."}, status=status.HTTP_200_OK)