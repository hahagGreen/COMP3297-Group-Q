from celery import shared_task
from django.utils import timezone
from .models import Reservation

@shared_task
def expire_temp_reservations():
    expired = Reservation.objects.filter(
        status=Reservation.TEMP,
        expires_at__lte=timezone.now()
    ).update(status=Reservation.CANCELED)
    
    return f"Expired {expired} reservations"
