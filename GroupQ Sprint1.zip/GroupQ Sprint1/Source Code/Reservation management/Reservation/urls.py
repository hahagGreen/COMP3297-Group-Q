# reservations/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from . import views
from .views import ReservationViewSet, add_reservation, reservation_list, delete_reservation, modify_reservation, assume, send_email

router = DefaultRouter()
router.register(r'reservations', ReservationViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path("assume/", assume, name="assume"),
    path('add_reservation/', add_reservation, name='add_reservation'),
    path('reservation_list/', reservation_list, name='reservation_list'),
    path('delete_reservation/<int:reservation_id>/', delete_reservation, name='delete_reservation'),
    path('modify_reservation/<int:reservation_id>/', modify_reservation, name='modify_reservation'),
    path('send_email/', send_email, name='send_email'),
]
