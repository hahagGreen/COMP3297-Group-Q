from datetime import datetime, timedelta

from absl.flags import ValidationError
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from Reservation.models import Reservation

from .models import User, Accommodation
#from models import *
from .serializers import ReservationSerializer


from django.shortcuts import render, redirect, get_object_or_404
from django.utils.timezone import now, make_aware
from .models import Reservation, Accommodation, User

from django.shortcuts import render, get_object_or_404
from .models import User, Accommodation

from django.shortcuts import render

from django.shortcuts import render, get_object_or_404
from .models import Reservation, User

from django.core.mail import send_mail
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from .models import EmailRecord

def assume(request):

    #accommodation_id = request.GET.get('accommodation')
    return render(request, 'assume.html')



def add_reservation(request):
    if request.method == "POST":
        expires_at = request.POST.get('expires_at')
        status = request.POST.get('status')
        user_id = request.POST.get("user_id")  # Fetch the value of 'user_id'
        user = get_object_or_404(User, pk=user_id)
        accommodation_id = request.POST.get("accommodation_id")
        accommodation = get_object_or_404(Accommodation, pk=accommodation_id)
        
        # Validate required fields
        if not accommodation_id or not expires_at or not status:
            return render(request, 'add_reservation.html', {
                'user_id': user_id,
                'user_name': user.name,
                'accommodation_type': accommodation,
                'accommodation_id': accommodation_id,
                'error_message': 'All fields are required.',
            })

        try:

            # Check if the accommodation is already reserved
            if accommodation.is_reserved and status == Reservation.CONFIRMED:
                return render(request, 'add_reservation.html', {
                    'user_id': user_id,
                    'user_name': user.name,
                    'accommodation_type': accommodation,
                    'accommodation_id': accommodation_id,
                    'error_message': 'The selected accommodation is already reserved.',
                })
            accommodation.is_reserved = True

            # Create and save the new reservation
            reservation = Reservation(
                user=user,
                accommodation=accommodation,
                expires_at=expires_at,
                status=status,
            )
            reservation.save()

            # send confirmation email
            subject = "Reservation Added"
            message = f"Dear {user.name},\n\nYour reservation for {accommodation.type} has been successfully added.\n\nBest regards,\nUniHaven Team"
            send_mail(subject, message, None, [user.email])

            # Redirect to reservation list
            reservation_list_url = reverse('reservation_list') + f'?user_id={user_id}'
            return redirect(reservation_list_url)

        except Exception as e:
            return render(request, 'add_reservation.html', {
                'user_id': user_id,
                'user_name': user.name,
                'accommodation_type': accommodation,
                'accommodation_id': accommodation_id,
                'error_message': str(e),
            })
    user_id = request.GET.get("user_id")
    accommodation_id = request.GET.get('accommodation_id')
    #print(user_id)
    user = get_object_or_404(User, pk=user_id)
    #print(accommodation_id)
    accommodation = get_object_or_404(Accommodation, pk=accommodation_id)
    # Render the form for GET requests
    return render(request, 'add_reservation.html', {
        'user_id': user_id,
        'user_name' : user.name,
        'accommodation_type': accommodation,
        'accommodation_id': accommodation_id
    })


def modify_reservation(request, reservation_id):
    reservation = get_object_or_404(Reservation, pk=reservation_id)
    user_id = reservation.user.pk

    # Check if reservation is confirmed - prevent modification
    if reservation.status == Reservation.CONFIRMED:
        return render(request, 'modify_reservation.html', {
            'user_id': user_id,
            'reservation': reservation,
            'error_message': 'Cannot modify confirmed reservations.',
            'is_confirmed': True  # Add flag to template for UI handling
        })

    if request.method == "POST":
        accommodation_id = request.POST.get('accommodation')
        expires_at = request.POST.get('expires_at')

        try:
            # Update accommodation if provided
            if accommodation_id:
                accommodation = get_object_or_404(Accommodation, pk=accommodation_id)
                if accommodation.is_reserved and accommodation != reservation.accommodation:
                    return render(request, 'modify_reservation.html', {
                        'user_id': user_id,
                        'reservation': reservation,
                        'accommodations': Accommodation.objects.filter(is_reserved=False) | Accommodation.objects.filter(pk=reservation.accommodation.pk),
                        'error_message': 'The selected accommodation is already reserved.',
                    })
                reservation.accommodation = accommodation

            # Update expiration date if provided
            if expires_at:
                # Parse datetime and make it timezone-aware
                naive_datetime = datetime.strptime(expires_at, "%Y-%m-%dT%H:%M")
                reservation.expires_at = make_aware(naive_datetime)

            reservation.save()

            # send confirmation email
            subject = "Reservation Modified"
            message = f"Dear {reservation.user.name},\n\nYour reservation for {reservation.accommodation.type} has been successfully modified.\n\nBest regards,\nUniHaven Team"
            send_mail(subject, message, None, [reservation.user.email])

            # Redirect to reservation list
            reservation_list_url = reverse('reservation_list') + f'?user_id={user_id}'
            return redirect(reservation_list_url)

        except Exception as e:
            import traceback
            print("Error occurred:", str(e))
            print(traceback.format_exc())  # Debugging exception
            return render(request, 'modify_reservation.html', {
                'user_id': user_id,
                'reservation': reservation,
                'accommodations': reservation.accommodation.type,
                'error_message': str(e),
            })

    # Render the form with the current reservation details
    accommodations = Accommodation.objects.filter(is_reserved=False) | Accommodation.objects.filter(pk=reservation.accommodation.pk)
    return render(request, 'modify_reservation.html', {
        'user_id': user_id,
        'reservation': reservation,
        'accommodations': reservation.accommodation.type,
        'is_confirmed': False  # Add flag to template for UI handling
    })


def reservation_list(request):
    user_id = request.GET.get("user_id")
    user = get_object_or_404(User, pk=user_id)

    # Get all reservations for the user
    reservations = Reservation.objects.filter(user=user)

    # Filter reservations with status "temporary" and check for expiration
    temporary_reservations = reservations.filter(status="temp")
    for reservation in temporary_reservations:
        # Check if 10 seconds have passed since creation_time
        if now() - reservation.created_at > timedelta(hours=24):
            # Update accommodation's reserved status to False
            reservation.accommodation.is_reserved = False
            reservation.accommodation.save()

            # Delete the expired reservation
            reservation.delete()

    # Refresh the reservations queryset after cleanup
    reservations = Reservation.objects.filter(user=user)

    return render(request, 'reservation_list.html', {
        'user_id': user_id,
        'reservations': reservations,
    })


def delete_reservation(request, reservation_id):
    #user_id = request.GET.get("user_id")

    #user = get_object_or_404(User, pk=user_id)
    reservation = get_object_or_404(Reservation, pk=reservation_id)  # Ensure reservation belongs to the user
    user_id = reservation.user.user_id

    # Check if reservation is confirmed - prevent deletion
    if reservation.status == Reservation.CONFIRMED:
        return render(request, 'delete_reservation.html', {
            'user_id': user_id,
            'reservation': reservation,
            'error_message': 'Cannot delete confirmed reservations.',
            'is_confirmed': True  # Add flag to template for UI handling
        })
    
    if request.method == "POST":
        reservation.delete()

        # send confirmation email
        subject = "Reservation Deleted"
        message = f"Dear {reservation.user.name},\n\nYour reservation for {reservation.accommodation.type} has been successfully deleted.\n\nBest regards,\nUniHaven Team"
        send_mail(subject, message, None, [reservation.user.email])

        reservation_list_url = reverse('reservation_list') + f'?user_id={user_id}'
        return redirect(reservation_list_url)  # Redirect to the list page after deletion

    # Render a confirmation page
    return render(request, 'delete_reservation.html', {
        'user_id': user_id,
        'reservation': reservation,
    })


class ReservationViewSet(viewsets.ModelViewSet):
    queryset = Reservation.objects.all()
    serializer_class = ReservationSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=True, methods=['post'])
    def confirm(self, request, pk=None):
        reservation = self.get_object()
        if reservation.status == Reservation.TEMP:
            reservation.status = Reservation.CONFIRMED
            reservation.save()
            return Response({'status': 'confirmed'})
        return Response({'error': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        reservation = self.get_object()
        if reservation.status in [Reservation.TEMP, Reservation.CONFIRMED]:
            reservation.status = Reservation.CANCELED
            reservation.save()
            return Response({'status': 'canceled'})
        return Response({'error': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)


def send_email(request):
    if request.method == "POST":
        subject = request.POST.get("subject")
        message_content = request.POST.get("message")
        to_email = request.POST.get("to_email")
        if subject and message_content and to_email:
            try:
                send_mail(subject, message_content, None, [to_email])
                # Save email record in DB
                EmailRecord.objects.create(
                    subject=subject,
                    message=message_content,
                    to_email=to_email
                )
                messages.success(request, "Email sent successfully!")
                return redirect("send_email")
            except Exception as e:
                messages.error(request, f"Failed to send email: {e}")
        else:
            messages.error(request, "All fields are required.")
    return render(request, "send_email.html")