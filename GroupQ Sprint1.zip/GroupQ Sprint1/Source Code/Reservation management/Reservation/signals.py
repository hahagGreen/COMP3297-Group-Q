# reservations/signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from .models import Reservation, User


@receiver(post_save, sender=Reservation)
def send_reservation_notification(sender, instance, **kwargs):
    if instance.status in [Reservation.CONFIRMED, Reservation.CANCELED]:
        specialists = User.objects.filter(role=User.SPECIALIST)
        emails = [s.email for s in specialists]
        
        subject = f"Reservation {instance.reservation_id} {instance.get_status_display()}"
        message = f"""
        Reservation Details:
        User: {instance.user.name}
        Accommodation: {instance.accommodation.address}
        Status: {instance.get_status_display()}
        """
        
        send_mail(
            subject,
            message,
            'noreply@unihaven.com',
            emails,
            fail_silently=False,
        )
