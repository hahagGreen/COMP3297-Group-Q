At this moment "Core accommodation search & filtering" and "Reservation Management" can be run separately. 
"Accommodation details & geolocation" is includes:
	viewAddDetails.py: A geolocation processing module responsible for fetching geographical coordinates (latitude and longitude) and geo-address information via an external API.
	findGeoAddress.py: A core management module for accommodations. It focuses on handling accommodation details, including adding, retrieving, and displaying them.
	*It is not runnable and we plan to finish its front end UI and back end logic in next sprint